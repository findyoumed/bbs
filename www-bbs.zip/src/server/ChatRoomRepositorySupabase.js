'use strict';
const { createClient } = require('@supabase/supabase-js');
const BaseRepository = require('./BaseRepository');
const { createHttpError, maybeUuid, normalizeMaxUser, normalizeRoomSecret, normalizeRoomText, normalizeSessionKey, normalizeText, publicRoom, summarizeParticipantCounts, roomKeyForNo } = require('./ChatRoomRepositoryShared');
const { ChatRoomMemberPersistence } = require('./ChatRoomMemberPersistence');
const { ChatRoomRepositorySupabaseQueries } = require('./ChatRoomRepositorySupabaseQueries');

class SupabaseChatRoomRepository extends BaseRepository {
  constructor(options = {}) {
    super({ ...options, driverName: 'supabase' });
    this.client = createClient(options.url, options.serviceRoleKey, { auth: { persistSession: false } });
    this.table = options.table || 'chat_rooms';
    this.membersTable = options.membersTable || 'chat_room_members';
    this.participantTtlMs = Number(options.participantTtlMs ?? 1000 * 60 * 60 * 6);
    this.roomTtlMs = Number(options.roomTtlMs ?? 0);
    this.defaultRoom = options.defaultRoom !== false;
    this.participantsByRoomNo = new Map();
    this.messagesByRoomNo = new Map();
    // [LOG_ID: 20260718_1800] 방장 세션 추적(방번호→sessionKey). 그 세션이 나가면 방을 종료한다
    // (olddos 원본 규칙). userId가 아니라 sessionKey 기준이라 게스트 'guest' 충돌이 없다.
    this.ownerSessionByRoomNo = new Map();
    this.defaultRoomPromise = null;
    this.memberPersistence = new ChatRoomMemberPersistence({ client: this.client, membersTable: this.membersTable, participantTtlMs: this.participantTtlMs });
    this.queries = new ChatRoomRepositorySupabaseQueries(this.client, this.table);
  }

  getMeta() {
    return {
      ...super.getMeta(),
      table: this.table,
      membersTable: this.membersTable,
      participantPersistence: 'auth-members:database, sessions:memory'
    };
  }

  async list() {
    await this._ensureDefaultRoom(); await this._cleanup();
    const rows = await this.queries.listRows();
    const authCounts = await this.memberPersistence.loadActiveAuthMemberCounts(rows.map(r => r.id));
    return rows.map(r => this._toPublicRoom(r, summarizeParticipantCounts(this._participantsForRoom(r.room_no), authCounts.get(r.id) || 0)));
  }

  async get(roomNo) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const row = await this.queries.findRoomByNo(roomNo);
    const authCount = await this.memberPersistence.loadActiveAuthMemberCount(row.id);
    return this._toPublicRoom(row, summarizeParticipantCounts(this._participantsForRoom(row.room_no), authCount));
  }

  async create(payload = {}, context = {}) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const title = normalizeRoomText(payload.title); if (!title) throw createHttpError(400, '제목 필수');
    const greeting = normalizeRoomText(payload.greeting); if (!greeting) throw createHttpError(400, '환영 메시지 필수');
    const isPrivate = ['private', 'secret', '2'].includes(normalizeText(payload.visibility || payload.mode || 'public').toLowerCase());
    const password = isPrivate ? normalizeRoomSecret(payload.password || '') : '';
    if (isPrivate && password.length < 4) throw createHttpError(400, '비밀번호 4자 이상');

    for (let i = 0; i < 5; i++) {
      const nextNo = await this.queries.nextRoomNo();
      const { data, error } = await this.client.from(this.table).insert({
        room_no: nextNo, room_key: roomKeyForNo(nextNo), name: title.slice(0, 60), description: greeting.slice(0, 120),
        owner_user_id: normalizeText(context.userId, 'guest'), owner_name: normalizeText(context.nickName, '손님'),
        creator_id: maybeUuid(context.userId), max_user: normalizeMaxUser(payload.maxUser, 10), password, is_private: isPrivate, is_locked: false, last_activity_at: new Date().toISOString()
      }).select(this.queries._selectColumns()).single();
      if (!error) return this._toPublicRoom(data);
      if (!this._isConflict(error)) throw createHttpError(502, `생성 실패: ${error.message}`);
    }
    throw createHttpError(502, '방 번호 할당 실패');
  }

  async join(roomNo, payload = {}, context = {}) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const room = await this.queries.findRoomByNo(roomNo);
    if (room.password && room.password !== normalizeRoomSecret(payload.password || '')) throw createHttpError(403, '비밀번호 틀림');
    const sessionKey = normalizeSessionKey(payload.sessionKey), participants = this._participantsForRoom(room.room_no);
    const existing = participants.find(p => p.sessionKey === sessionKey), now = new Date().toISOString();
    const p = { sessionKey, userId: normalizeText(context.userId, 'guest'), nickName: normalizeText(context.nickName, '손님'), joinedAt: existing?.joinedAt || now, lastSeenAt: now };
    const authCount = await this.memberPersistence.loadActiveAuthMemberCount(room.id);
    const nextSummary = summarizeParticipantCounts(existing ? participants.map(e => e.sessionKey === sessionKey ? p : e) : participants.concat([p]), authCount);
    if (!existing && nextSummary.userCount > normalizeMaxUser(room.max_user, 99)) throw createHttpError(409, '정원 초과');
    if (existing) Object.assign(existing, p); else participants.push(p);
    this.participantsByRoomNo.set(Number(room.room_no), participants);
    // [LOG_ID: 20260718_1800] 개설자(userId===owner_user_id)의 첫 입장에서 방장 세션을 못박는다.
    // 개설 직후 개설자가 가장 먼저 입장하므로 게스트라도 최초 입장자=개설자가 보장된다.
    if (!this.ownerSessionByRoomNo.get(Number(room.room_no)) && p.userId === room.owner_user_id) {
      this.ownerSessionByRoomNo.set(Number(room.room_no), sessionKey);
    }
    await this.memberPersistence.persistJoin(room, p); await this._touch(room.room_no);
    room.last_activity_at = now; return this._toPublicRoom(room, nextSummary);
  }

  async leave(roomNo, payload = {}, context = {}) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const room = await this.queries.findRoomByNo(roomNo), sessionKey = payload.sessionKey ? normalizeSessionKey(payload.sessionKey) : '';

    // [LOG_ID: 20260718_1800] 방장 세션이 나가면 방을 종료한다(원본 규칙). 기본방(#1)은 제외한다.
    // 남은 참여자는 다음 폴링에서 방이 사라진 것을 보고 대기실로 돌아간다.
    const ownerSession = this.ownerSessionByRoomNo.get(Number(room.room_no));
    if (sessionKey && ownerSession && sessionKey === ownerSession && Number(room.room_no) !== 1) {
      this.participantsByRoomNo.delete(Number(room.room_no));
      this.messagesByRoomNo.delete(Number(room.room_no));
      this.ownerSessionByRoomNo.delete(Number(room.room_no));
      await this.client.from(this.table).delete().eq('room_no', room.room_no);
      return this._toPublicRoom({ ...room, _closed: true }, summarizeParticipantCounts([]));
    }

    const filtered = this._participantsForRoom(room.room_no).filter(p => p.sessionKey !== sessionKey);
    if (filtered.length) this.participantsByRoomNo.set(Number(room.room_no), filtered); else this.participantsByRoomNo.delete(Number(room.room_no));
    await this.memberPersistence.persistLeave(room, payload, context, filtered);
    const authCount = await this.memberPersistence.loadActiveAuthMemberCount(room.id);
    await this._touch(room.room_no); room.last_activity_at = new Date().toISOString();
    return this._toPublicRoom(room, summarizeParticipantCounts(filtered, authCount));
  }

  // [LOG_ID: 20260714_2200] 원전 /OUT id(강퇴) 재현 — 방 개설자(owner_user_id)만 실행 가능.
  // 세션 목록에서만 제거(참여자 수/목록에 즉시 반영) — leave()도 메시지 전송을 별도로 막지
  // 않는 동일한 얕은 프레즌스 모델이라, 강퇴도 그 이상을 강제하지 않는다.
  async kick(roomNo, targetUserId, context = {}) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const room = await this.queries.findRoomByNo(roomNo);
    const requesterId = normalizeText(context.userId, 'guest');
    if (room.owner_user_id !== requesterId) throw createHttpError(403, '방 개설자만 강퇴할 수 있습니다.');
    const target = normalizeText(targetUserId, '');
    const participants = this._participantsForRoom(room.room_no);
    const before = participants.length;
    const filtered = participants.filter(p => p.userId !== target);
    if (filtered.length === before) throw createHttpError(404, '해당 이용자가 방에 없습니다.');
    if (filtered.length) this.participantsByRoomNo.set(Number(room.room_no), filtered); else this.participantsByRoomNo.delete(Number(room.room_no));
    const authCount = await this.memberPersistence.loadActiveAuthMemberCount(room.id);
    return this._toPublicRoom(room, summarizeParticipantCounts(filtered, authCount));
  }

  // [LOG_ID: 20260714_2200] 원전 /E TITLE, /E USER(방 설정 변경) 재현 — 방 개설자 전용.
  async updateRoom(roomNo, payload = {}, context = {}) {
    await this._ensureDefaultRoom(); await this._cleanup();
    const room = await this.queries.findRoomByNo(roomNo);
    const requesterId = normalizeText(context.userId, 'guest');
    if (room.owner_user_id !== requesterId) throw createHttpError(403, '방 개설자만 설정을 변경할 수 있습니다.');
    const updates = {};
    if (payload.title !== undefined) {
      const title = normalizeRoomText(payload.title);
      if (!title) throw createHttpError(400, '방 제목을 입력해 주세요.');
      updates.name = title.slice(0, 60);
    }
    if (payload.maxUser !== undefined) {
      updates.max_user = normalizeMaxUser(payload.maxUser, room.max_user);
    }
    if (Object.keys(updates).length === 0) return this._toPublicRoom(room);
    const { data, error } = await this.client.from(this.table).update(updates).eq('room_no', Number(roomNo)).select(this.queries._selectColumns()).single();
    if (error) throw createHttpError(502, `수정 실패: ${error.message}`);
    return this._toPublicRoom(data);
  }

  async sendMessage(roomNo, payload = {}, context = {}) {
    const num = Number(roomNo);
    const messages = this.messagesByRoomNo.get(num) || [];
    const msg = {
      id: Date.now() + Math.random(),
      userId: normalizeText(context.userId, 'guest'),
      nickName: normalizeText(context.nickName, '손님'),
      content: normalizeText(payload.content),
      createdAt: new Date().toISOString()
    };
    messages.push(msg);
    if (messages.length > 100) messages.shift(); // 최근 100개 유지
    this.messagesByRoomNo.set(num, messages);
    await this._touch(num);
    return msg;
  }

  async listMessages(roomNo) {
    await this.queries.findRoomByNo(roomNo);
    return this.messagesByRoomNo.get(Number(roomNo)) || [];
  }

  _toPublicRoom(row, summary = null) {
    const n = Number(row.room_no || 0);
    return publicRoom({ no: n, roomId: normalizeText(row.room_key, roomKeyForNo(n)), title: row.name, greeting: row.description, ownerUserId: row.owner_user_id, ownerName: row.owner_name, maxUser: row.max_user, password: row.password, isPrivate: row.is_private, createdAt: row.created_at }, summary || summarizeParticipantCounts(this._participantsForRoom(n), 0));
  }

  _participantsForRoom(no) {
    const num = Number(no || 0), list = (this.participantsByRoomNo.get(num) || []).filter(p => Date.parse(p.lastSeenAt || p.joinedAt) >= Date.now() - this.participantTtlMs);
    if (list.length) this.participantsByRoomNo.set(num, list); else this.participantsByRoomNo.delete(num);
    return list;
  }

  async _cleanup() {
    Array.from(this.participantsByRoomNo.keys()).forEach(n => this._participantsForRoom(n));
    await this.memberPersistence.cleanupExpired();
    if (this.roomTtlMs <= 0) return;
    const { data, error } = await this.client.from(this.table).select('room_no').neq('room_no', 1).eq('is_locked', false).lt('last_activity_at', new Date(Date.now() - this.roomTtlMs).toISOString());
    if (error) return;
    for (const r of data || []) {
      if (this._participantsForRoom(r.room_no).length === 0) await this.client.from(this.table).delete().eq('room_no', r.room_no);
    }
  }

  async _ensureDefaultRoom() {
    if (!this.defaultRoom) return;
    if (!this.defaultRoomPromise) this.defaultRoomPromise = (async () => {
      const { data } = await this.client.from(this.table).select('id').eq('room_no', 1).maybeSingle();
      return data || await this.queries.createDefaultRoom();
    })();
    await this.defaultRoomPromise;
  }

  _isConflict(e) { return String(e?.message).toLowerCase().includes('duplicate key'); }
  async _touch(n) { await this.client.from(this.table).update({ last_activity_at: new Date().toISOString() }).eq('room_no', Number(n)); }
}

module.exports = { SupabaseChatRoomRepository };
