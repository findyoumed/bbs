'use strict';

const Module = require('module');
const path = require('path');
const { EventEmitter } = require('events');

const BaseRouter = require('../../../../src/server/routeHandlers/BaseRouter');
const {
  buildCorsHeaders,
  maybeUuid,
  normalizeMultilineText,
  parseAllowedOrigins,
  readJsonBody,
  safeResolve,
  stripControlCharacters,
  validateEmail,
  validateNickName
} = require('../../../../src/server/httpUtils');

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message} (expected: ${expected}, actual: ${actual})`);   
  }
}

async function assertRejects(promise, predicate, message) {
  let error = null;
  try {
    await promise;
  } catch (caught) {
    error = caught;
  }

  if (!error) {
    throw new Error(`${message} (expected rejection)`);
  }

  if (!predicate(error)) {
    throw new Error(`${message} (unexpected error: ${error.message})`);
  }
}

function createMockRequest(method) {
  const req = new EventEmitter();
  req.method = method;
  req.resumeCalls = 0;
  req.resume = () => {
    req.resumeCalls += 1;
  };
  return req;
}

function createRouteContext(method, url) {
  const req = createMockRequest(method);
  req.headers = {};
  const res = {
    statusCode: 0,
    headers: null,
    payload: '',
    writeHead(statusCode, headers) {
      this.statusCode = statusCode;
      this.headers = headers;
    },
    end(payload) {
      this.payload = String(payload ?? '');
    }
  };

  return {
    req,
    res,
    requestUrl: new URL(url)
  };
}

function setMockModule(modulePath, exportsValue) {
  const mockModule = new Module(modulePath);
  mockModule.filename = modulePath;
  mockModule.loaded = true;
  mockModule.exports = exportsValue;
  require.cache[modulePath] = mockModule;
}

module.exports = (async () => {
  console.log('Running httpUtils tests...');

  assertEqual(
    maybeUuid('550e8400-e29b-41d4-a716-446655440000'),
    '550e8400-e29b-41d4-a716-446655440000',
    'maybeUuid should keep valid UUID values'
  );
  assertEqual(maybeUuid('not-a-uuid'), null, 'maybeUuid should reject invalid UUID values');

  assertEqual(
    normalizeMultilineText('line1\r\nline2\rline3'),
    'line1\nline2\nline3',
    'normalizeMultilineText should normalize CRLF and CR newlines'
  );
  assertEqual(
    stripControlCharacters('hello\u0000world\u001f!'),
    'hello world !',
    'stripControlCharacters should replace control characters with spaces'      
  );

  const allowedOrigins = parseAllowedOrigins(' https://a.example , https://a.example, , https://b.example ');
  assertEqual(
    JSON.stringify(allowedOrigins),
    JSON.stringify(['https://a.example', 'https://b.example']),
    'parseAllowedOrigins should trim and deduplicate configured origins'        
  );

  const matchedCorsHeaders = buildCorsHeaders('https://b.example', allowedOrigins);
  assertEqual(
    matchedCorsHeaders['Access-Control-Allow-Origin'],
    'https://b.example',
    'buildCorsHeaders should echo the matched allowlisted origin'
  );
  assertEqual(matchedCorsHeaders.Vary, 'Origin', 'allowlisted CORS responses should vary by Origin');

  const fallbackCorsHeaders = buildCorsHeaders('https://unknown.example', allowedOrigins);
  assertEqual(
    fallbackCorsHeaders['Access-Control-Allow-Origin'],
    'https://a.example',
    'buildCorsHeaders should fall back to the first configured origin when the request origin is unknown'
  );
  assertEqual(
    buildCorsHeaders('', [])['Access-Control-Allow-Origin'],
    '*',
    'buildCorsHeaders should allow wildcard origins when no allowlist is configured'
  );

  const basePath = `${path.resolve('tmp-http-utils-base')}${path.sep}`;
  assertEqual(
    safeResolve(basePath, '/js/app.js'),
    path.resolve(path.resolve('tmp-http-utils-base'), 'js/app.js'),
    'safeResolve should keep nested paths inside the base directory even when the base path has a trailing separator'
  );
  assertEqual(safeResolve(basePath, '/../secret.txt'), '', 'safeResolve should reject parent traversal');
  assertEqual(safeResolve('', '/index.html'), '', 'safeResolve should reject blank base paths');

  assertEqual(validateNickName('  운영자  '), '운영자', 'validateNickName should trim valid nicknames');
  await assertRejects(
    Promise.resolve().then(() => validateNickName('a')),
    (error) => error.status === 400 && /2자 이상/.test(error.message),
    'validateNickName should reject nicknames that are too short'
  );
  await assertRejects(
    Promise.resolve().then(() => validateNickName('관리자\u0000')),
    (error) => error.status === 400 && /허용되지 않는 문자/.test(error.message),
    'validateNickName should reject nicknames with control characters'
  );

  assertEqual(validateEmail(''), '', 'validateEmail should allow empty email values');
  assertEqual(
    validateEmail('  USER@Example.COM  '),
    'user@example.com',
    'validateEmail should trim and lowercase valid email values'
  );
  await assertRejects(
    Promise.resolve().then(() => validateEmail('not-an-email')),
    (error) => error.status === 400 && /이메일 형식/.test(error.message),       
    'validateEmail should reject malformed email values'
  );

  const getReq = createMockRequest('GET');
  assertEqual(await readJsonBody(getReq), null, 'readJsonBody should ignore methods without JSON bodies');

  const postReq = createMockRequest('POST');
  const parsedBodyPromise = readJsonBody(postReq);
  postReq.emit('data', Buffer.from('{"title":"hello","count":2}', 'utf8'));     
  postReq.emit('end');
  const parsedBody = await parsedBodyPromise;
  assertEqual(parsedBody.title, 'hello', 'readJsonBody should parse JSON payloads');
  assertEqual(parsedBody.count, 2, 'readJsonBody should preserve numeric payload fields');

  const cachedReq = createMockRequest('POST');
  const firstCachedPromise = readJsonBody(cachedReq);
  const secondCachedPromise = readJsonBody(cachedReq);
  assert(
    firstCachedPromise === secondCachedPromise,
    'readJsonBody should reuse the same promise when the same request body is read twice'
  );
  cachedReq.emit('data', Buffer.from('{"title":"cached"}', 'utf8'));
  cachedReq.emit('end');
  const cachedBody = await secondCachedPromise;
  assertEqual(cachedBody.title, 'cached', 'cached request body reads should resolve with the parsed payload');

  const invalidReq = createMockRequest('POST');
  const invalidBodyPromise = readJsonBody(invalidReq);
  invalidReq.emit('data', '{oops');
  invalidReq.emit('end');
  await assertRejects(
    invalidBodyPromise,
    (error) => error.status === 400 && error.message === 'Invalid JSON body',   
    'readJsonBody should reject malformed JSON payloads'
  );

  const oversizedReq = createMockRequest('POST');
  const oversizedBodyPromise = readJsonBody(oversizedReq);
  oversizedReq.emit('data', Buffer.alloc((1024 * 1024) + 1, 'a'));
  await assertRejects(
    oversizedBodyPromise,
    (error) => error.status === 413 && error.message === 'Request body too large',
    'readJsonBody should reject payloads larger than 1MB'
  );
  assertEqual(oversizedReq.resumeCalls, 1, 'oversized payloads should drain the remaining request body');

  const getContext = createRouteContext('GET', 'https://bbs.example/api/test/42?page=2');
  const getRouter = new BaseRouter(getContext);
  assertEqual(getRouter.pathname, '/api/test/42', 'BaseRouter should capture the request pathname');
  assertEqual(getRouter.method, 'GET', 'BaseRouter should capture the request method');
  assertEqual(
    JSON.stringify(getRouter.match('GET', '/api/test/42')),
    JSON.stringify({}),
    'BaseRouter.match should support exact string routes'
  );
  assertEqual(getRouter.match('POST', '/api/test/42'), null, 'BaseRouter.match should reject mismatched methods');
  assertEqual(getRouter.match('GET', '/api/test/99'), null, 'BaseRouter.match should reject different string paths');
  const regexMatch = getRouter.match('GET', /^\/api\/test\/(\d+)$/);
  assert(regexMatch && regexMatch[1] === '42', 'BaseRouter.match should return RegExp captures when the path matches');
  assertEqual(getRouter.match('GET', 1234), null, 'BaseRouter.match should ignore unsupported matcher types');

  const postRouteContext = createRouteContext('POST', 'https://bbs.example/api/test');
  const postRouter = new BaseRouter(postRouteContext);
  const routedBodyPromise = postRouter.readBody();
  postRouteContext.req.emit('data', Buffer.from('{"boardId":"plaza","page":2}', 'utf8'));
  postRouteContext.req.emit('end');
  const routedBody = await routedBodyPromise;
  assertEqual(routedBody.boardId, 'plaza', 'BaseRouter.readBody should parse JSON request bodies');
  assertEqual(routedBody.page, 2, 'BaseRouter.readBody should preserve parsed field values');

  const sendContext = createRouteContext('GET', 'https://bbs.example/api/send');
  const sendRouter = new BaseRouter(sendContext);
  assertEqual(sendRouter.send(201, { success: true }), true, 'BaseRouter.send should report handled responses');
  assertEqual(sendContext.res.statusCode, 201, 'BaseRouter.send should write the provided status code');
  assertEqual(
    sendContext.res.headers['Content-Type'],
    'application/json; charset=utf-8',
    'BaseRouter.send should respond with the JSON content type'
  );
  
  const response = JSON.parse(sendContext.res.payload);
  assertEqual(response.success, true, 'BaseRouter.send should include success flag');
  assertEqual(response.status, 201, 'BaseRouter.send should include status code');
  assertEqual(response.message, 'Success', 'BaseRouter.send should include default message');
  assertEqual(response.data.success, true, 'BaseRouter.send should include original data');
  assert(
    /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(response.timestamp),
    'BaseRouter.send should include ISO timestamp'
  );

  await assertRejects(
    Promise.resolve().then(() => getRouter.error(418, 'teapot')),
    (error) => error.status === 418 && error.message === 'teapot',
    'BaseRouter.error should throw HTTP-flavored errors'
  );

  const memberContext = { userId: 'neo', isGuest: false };
  assertEqual(
    await getRouter.ensureAuthenticated(memberContext),
    memberContext,
    'BaseRouter.ensureAuthenticated should allow logged-in users'
  );
  await assertRejects(
    getRouter.ensureAuthenticated({ isGuest: true }),
    (error) => error.status === 401 && /로그인/.test(error.message),
    'BaseRouter.ensureAuthenticated should reject guest contexts'
  );
  await assertRejects(
    getRouter.ensureAuthenticated(null),
    (error) => error.status === 401,
    'BaseRouter.ensureAuthenticated should reject missing contexts'
  );

  const adminContext = { userId: 'sysop', isAdmin: true };
  assertEqual(await getRouter.ensureAdmin(adminContext), adminContext, 'BaseRouter.ensureAdmin should allow admins');
  await assertRejects(
    getRouter.ensureAdmin({ userId: 'neo', isAdmin: false }),
    (error) => error.status === 403 && /운영 권한/.test(error.message),
    'BaseRouter.ensureAdmin should reject non-admin users'
  );

  const apiRouterPath = path.resolve(__dirname, '../../../../src/server/apiRequestRouter.js');
  const handlerPaths = [
    path.resolve(__dirname, '../../../../src/server/routeHandlers/systemRoutes.js'),
    path.resolve(__dirname, '../../../../src/server/routeHandlers/authRoutes.js'),
    path.resolve(__dirname, '../../../../src/server/routeHandlers/memberRoutes.js'),
    path.resolve(__dirname, '../../../../src/server/routeHandlers/memoRoutes.js'),
    path.resolve(__dirname, '../../../../src/server/routeHandlers/chatServiceRoutes.js'),
    path.resolve(__dirname, '../../../../src/server/routeHandlers/boardRoutes.js')
  ];
  const previousCache = new Map([
    [apiRouterPath, require.cache[apiRouterPath]],
    ...handlerPaths.map((modulePath) => [modulePath, require.cache[modulePath]])
  ]);

  const systemHandler = async (routeContext) => {
    routeContext.calls.push('system');
    return routeContext.stopAt === 'system';
  };
  const authHandler = async (routeContext) => {
    routeContext.calls.push('auth');
    return routeContext.stopAt === 'auth';
  };
  const memberHandler = async (routeContext) => {
    routeContext.calls.push('member');
    return routeContext.stopAt === 'member';
  };
  const memoHandler = async (routeContext) => {
    routeContext.calls.push('memo');
    return routeContext.stopAt === 'memo';
  };
  const chatHandler = async (routeContext) => {
    routeContext.calls.push('chat');
    return routeContext.stopAt === 'chat';
  };
  const boardHandler = async (routeContext) => {
    routeContext.calls.push('board');
    return routeContext.stopAt === 'board';
  };

  try {
    setMockModule(handlerPaths[0], systemHandler);
    setMockModule(handlerPaths[1], authHandler);
    setMockModule(handlerPaths[2], memberHandler);
    setMockModule(handlerPaths[3], memoHandler);
    setMockModule(handlerPaths[4], chatHandler);
    setMockModule(handlerPaths[5], boardHandler);
    delete require.cache[apiRouterPath];

    const { API_ROUTE_HANDLERS, handleApiRequest } = require('../../../../src/server/apiRequestRouter');

    assertEqual(API_ROUTE_HANDLERS.length, 6, 'apiRequestRouter should expose every registered route handler');
    assert(API_ROUTE_HANDLERS[0] === systemHandler, 'apiRequestRouter should register system routes first');
    assert(API_ROUTE_HANDLERS[1] === authHandler, 'apiRequestRouter should register auth routes second');
    assert(API_ROUTE_HANDLERS[2] === memberHandler, 'apiRequestRouter should register member routes third');
    assert(API_ROUTE_HANDLERS[3] === memoHandler, 'apiRequestRouter should register memo routes fourth');
    assert(API_ROUTE_HANDLERS[4] === chatHandler, 'apiRequestRouter should register chat routes fifth');
    assert(API_ROUTE_HANDLERS[5] === boardHandler, 'apiRequestRouter should register board routes last');

    const memberRouteContext = { calls: [], stopAt: 'member' };
    assertEqual(
      await handleApiRequest(memberRouteContext),
      true,
      'handleApiRequest should return true when any handler matches'
    );
    assertEqual(
      JSON.stringify(memberRouteContext.calls),
      JSON.stringify(['system', 'auth', 'member']),
      'handleApiRequest should stop after the first handler that returns true'  
    );

    const noMatchContext = { calls: [], stopAt: '' };
    assertEqual(
      await handleApiRequest(noMatchContext),
      false,
      'handleApiRequest should return false when any handler matches'
    );
    assertEqual(
      JSON.stringify(noMatchContext.calls),
      JSON.stringify(['system', 'auth', 'member', 'memo', 'chat', 'board']),
      'handleApiRequest should try every handler when no route matches'
    );
  } finally {
    for (const [modulePath, cachedModule] of previousCache.entries()) {
      if (cachedModule) {
        require.cache[modulePath] = cachedModule;
      } else {
        delete require.cache[modulePath];
      }
    }
  }

  console.log('httpUtils tests passed!');
})();
